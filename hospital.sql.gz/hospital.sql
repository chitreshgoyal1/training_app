-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 27, 2012 at 03:46 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `3dflash`
--

CREATE TABLE IF NOT EXISTS `3dflash` (
  `id` int(11) NOT NULL auto_increment,
  `image` varchar(255) default NULL,
  `heading` varchar(255) default NULL,
  `tag_line` varchar(255) default NULL,
  `description` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `3dflash`
--

INSERT INTO `3dflash` (`id`, `image`, `heading`, `tag_line`, `description`) VALUES
(6, 'img_01.jpg', '58 W3c Valid xHTML Pages', 'Navkar Hospital', '58 W3c Valid xHTML Pages\r\n58 W3c Valid xHTML Pages58 W3c Valid xHTML Pages'),
(7, 'img_02.jpg', '58 W3c Valid', 'Navkar Hospital', 'Demo Description'),
(8, 'img_03.jpg', '58 W3c Valid', 'Navkar Hospital', ' Navkar Hospital Navkar Hospital Navkar Hospital Navkar Hospital'),
(9, 'img_04.jpg', '58 W3c Valid', 'Navkar Hospital', 'Navkar Hospital'),
(10, 'img_05.jpg', '58 W3c Valid xHTML Pages', 'Navkar Hospital', 'Navkar HospitalNavkar HospitalNavkar HospitalNavkar Hospital');

-- --------------------------------------------------------

--
-- Table structure for table `aboutus_header`
--

CREATE TABLE IF NOT EXISTS `aboutus_header` (
  `id` int(11) NOT NULL auto_increment,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `aboutus_header`
--

INSERT INTO `aboutus_header` (`id`, `image`) VALUES
(7, 'images (3).jpg'),
(6, 'images (2).jpg');

-- --------------------------------------------------------

--
-- Table structure for table `admininfo`
--

CREATE TABLE IF NOT EXISTS `admininfo` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `login` datetime NOT NULL,
  `logout` datetime NOT NULL,
  `login_status` tinyint(4) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `admininfo`
--

INSERT INTO `admininfo` (`id`, `username`, `password`, `login`, `logout`, `login_status`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2012-08-15 07:18:21', '2012-08-03 13:15:39', 1),
(2, 'superadmin', 'd9b2dcf718e50af6fd37f8c40d16b3c0', '2012-08-26 10:50:04', '2012-08-15 07:18:15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `advertisment`
--

CREATE TABLE IF NOT EXISTS `advertisment` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `advertisment`
--

INSERT INTO `advertisment` (`id`, `name`, `address`, `image`) VALUES
(3, 'SOOP', 'F-1/11 LIC', 'SOOP_download (5).jpg'),
(4, 'ROHAN', 'MOON', 'ROHAN_images.jpg'),
(5, 'Times Of INDIA', 'Property', 'Times Of INDIA_download (6).jpg');

-- --------------------------------------------------------

--
-- Table structure for table `background`
--

CREATE TABLE IF NOT EXISTS `background` (
  `id` int(11) NOT NULL auto_increment,
  `image` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `background`
--

INSERT INTO `background` (`id`, `image`) VALUES
(2, 'img07.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `catalog`
--

CREATE TABLE IF NOT EXISTS `catalog` (
  `catalogid` bigint(32) NOT NULL auto_increment,
  `catalogname` varchar(255) NOT NULL,
  `description` text,
  `parentid` bigint(32) NOT NULL default '0',
  `menu_link_id` int(11) NOT NULL,
  PRIMARY KEY  (`catalogid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `catalog`
--

INSERT INTO `catalog` (`catalogid`, `catalogname`, `description`, `parentid`, `menu_link_id`) VALUES
(2, 'Link 2', 'No ho ho ho', 1, 1),
(3, 'ramji', 'asdfasdfadsf', 1, 1),
(4, '23-3-2012', 'Killer', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `supercategory_id` int(11) NOT NULL default '1',
  `menu_link_id` int(11) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `supercategory_id`, `menu_link_id`) VALUES
(9, 'hhuu', 4, 2),
(2, 'SUB 1', 1, 1),
(3, 'SUB 11', 2, 1),
(4, 'SUB 2', 1, 7),
(6, 'RAM', 4, 1),
(7, 'SUB 13', 2, 2),
(8, 'TTRR', 4, 8),
(10, 'SUB 4', 1, 1),
(11, 'tytyty', 2, 1),
(12, 'SUB 3', 1, 1),
(13, 'SUB 12', 2, 2),
(14, 'sandesh', 5, 7);

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `menu_link_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `address`, `image`, `menu_link_id`) VALUES
(6, 'Chitresh', 'F-1/11 L.I.C. Flats', 'Chitresh_care_logo_29.jpg', 4);

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE IF NOT EXISTS `companies` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `image`) VALUES
(1, 'Voltas', 'Sony_voltas-img-logo.jpg'),
(2, 'Hitachi', 'Hitachi_hitachi_logo.jpg'),
(3, 'Toshiba', 'Samsung_Toshiba_logo[1].gif'),
(4, 'Mitsubishi', 'Carrier_mitsubishi-logo.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(11) NOT NULL auto_increment,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `query` text NOT NULL,
  `modifieddate` datetime NOT NULL,
  `status` int(11) NOT NULL COMMENT '1. Active 2. Deactive',
  `ans_state` int(11) NOT NULL COMMENT '1. Sent 2. Unsent',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `fname`, `lname`, `email`, `query`, `modifieddate`, `status`, `ans_state`) VALUES
(8, 'Shrikant', 'Singhal', 'singhalshrikant@gmail.com', 'sdfsd\r\n', '2010-01-30 17:18:24', 1, 1),
(7, 'Abhishek', 'Jain', 'singhalshrikant@gmail.com', 'sdfdsfs', '2010-01-30 16:56:16', 2, 1),
(9, 'ram', 'singha', 'a@g.co', 'sdfsd', '2010-01-30 17:35:13', 1, 2),
(10, 'shrikant', 'Singhal', 'sda@c.co', 'adsasd', '2010-02-01 10:39:45', 1, 2),
(11, 'fdsfsdfdsfsd', 'fdsfsd', '', 'fsdfsd', '2010-03-23 13:45:11', 2, 2),
(12, 'sdfsdf', 'fdsf', 'sdf', 'sdfdsfs', '2010-03-23 13:45:44', 2, 2),
(13, 'fdsfds', 'fdsfsdf', 'fsdfs', 'fsdf', '2010-03-23 13:47:16', 2, 2),
(14, 'fsdf', 'fdsfsd', 'fdsf', 'fdsf', '2010-03-23 13:48:11', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `fproduct`
--

CREATE TABLE IF NOT EXISTS `fproduct` (
  `id` int(11) NOT NULL auto_increment,
  `heading` varchar(255) NOT NULL,
  `imgurl` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `fproduct`
--

INSERT INTO `fproduct` (`id`, `heading`, `imgurl`, `description`) VALUES
(2, 'H2 Lorem ipsum dolor sit amet', 'paid-clients.jpg', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat'),
(16, 'H3 Lorem ipsum dolor sit amet', 'MBC-Website-Background.gif', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat'),
(17, 'H3 Lorem ipsum dolor sit amet', 'abstract-Green-and-orange-abstract-background-download-wallpapers.jpg', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat'),
(18, 'H4 Lorem ipsum dolor sit amet', '', 'Lorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit amet'),
(19, 'H5 Lorem ipsum dolor sit amet', '', 'Lorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit amet'),
(20, 'H6 Lorem ipsum dolor sit amet', '', 'Lorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit amet'),
(23, 'H7 Lorem ipsum dolor sit amet', '', 'Lorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit ametLorem ipsum dolor sit amet');

-- --------------------------------------------------------

--
-- Table structure for table `header`
--

CREATE TABLE IF NOT EXISTS `header` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `imageurl` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `header`
--

INSERT INTO `header` (`id`, `name`, `imageurl`) VALUES
(1, 'AIR CONDITIONER', 'AIR CONDITIONER_DSC_3502.JPG'),
(2, 'AGOAN ELECTRONICS', 'AGOAN ELECTRONICS_001.jpg'),
(3, 'REFRIGERATOR', 'REFRIGERATOR_DSC_3499.JPG'),
(4, 'LCD &PLAZMA', 'LCD &PLAZMA_DSC_3511.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `headercontent`
--

CREATE TABLE IF NOT EXISTS `headercontent` (
  `id` int(11) NOT NULL auto_increment,
  `content` text,
  `htag` varchar(200) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `headercontent`
--

INSERT INTO `headercontent` (`id`, `content`, `htag`) VALUES
(8, '<p><img src="/userfiles/image/404074_450420954991920_1247369965_n.jpg" width="750" height="163" border="0" align="absMiddle" alt="" />&nbsp;</p>', '<p>&nbsp;BEST MEDICAL</p>');

-- --------------------------------------------------------

--
-- Table structure for table `logo`
--

CREATE TABLE IF NOT EXISTS `logo` (
  `id` int(11) NOT NULL auto_increment,
  `image` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `logo`
--

INSERT INTO `logo` (`id`, `image`) VALUES
(1, 'logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `menu_link`
--

CREATE TABLE IF NOT EXISTS `menu_link` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL,
  `ordering` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `menu_link`
--

INSERT INTO `menu_link` (`id`, `name`, `ordering`) VALUES
(1, 'Home', 1),
(2, 'About Us', 2),
(4, 'Clients', 3),
(5, 'Link6', 6),
(7, 'gallery', 4),
(8, 'Link5', 5),
(11, 'Contact Us', 10);

-- --------------------------------------------------------

--
-- Table structure for table `newproducts`
--

CREATE TABLE IF NOT EXISTS `newproducts` (
  `id` int(255) NOT NULL auto_increment,
  `productname` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `p_code` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `newproducts`
--

INSERT INTO `newproducts` (`id`, `productname`, `url`, `p_code`) VALUES
(1, 'refrigrator', '1.png', 'newrefrigrator1'),
(2, 'airconditionar', '2.png', '2airrconditiona'),
(3, 'Air Cooler', '3.png', '33333air99');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `newsid` bigint(32) NOT NULL auto_increment,
  `catalogid` bigint(32) default NULL,
  `title` varchar(255) NOT NULL,
  `content` text,
  `picture` varchar(255) default NULL,
  `viewnum` bigint(32) default NULL,
  `adddate` date default NULL,
  `rating` float default NULL,
  `ratenum` bigint(32) default NULL,
  `source` varchar(50) default NULL,
  `sourceurl` varchar(50) default NULL,
  `isdisplay` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`newsid`),
  KEY `catalogid` (`catalogid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`newsid`, `catalogid`, `title`, `content`, `picture`, `viewnum`, `adddate`, `rating`, `ratenum`, `source`, `sourceurl`, `isdisplay`) VALUES
(6, 3, 'Shree', 'xyzldsjfdklj', '1332573127download (3).jpg', 38, '2012-03-17', 4.875, 8, '', '', 1),
(5, 3, 'lop', 'sdfasdfadsfadsfa', '1332573141download.jpg', 6, '2012-03-16', 4, 1, '', '', 1),
(4, 2, 'TRING', 'kjh', '1332573153download (3).jpg', 12, '2012-03-08', 4, 1, '', '', 1),
(7, 3, 'jsdfklj', 'jskdlfjklsdjfklsdj', '1332659926download (6).jpg', 2, '2012-03-25', 4, 1, '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `nproduct`
--

CREATE TABLE IF NOT EXISTS `nproduct` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `price` varchar(10) NOT NULL,
  `imgurl` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `co_name` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `p_code` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=103 ;

--
-- Dumping data for table `nproduct`
--

INSERT INTO `nproduct` (`id`, `name`, `price`, `imgurl`, `category`, `description`, `co_name`, `type`, `p_code`) VALUES
(101, 'Hello', '8000', 'Hello_download (4).jpg', 'Chitresh2', 'sdkjfldjsf', 96, 'sdkfj', '1011'),
(99, 'asldkjf', '787', 'asldkjf_Chitresh1.jpg', 'Chitresh2', 'asdfjkldsj', 100, 'sdfjfdkjl', '7878'),
(100, 'rtyrt', '34342', 'rtyrt_download (4).jpg', 'Chitresh2', 'dfgdsfsdf', 0, 'gdfgdfg', '4545'),
(102, 'sfdjl', '24434', 'sfdjl_images.jpg', 'Chitresh45', 'lksdjfkdjfklsj', 102, '34', 'sdfkljsdkf');

-- --------------------------------------------------------

--
-- Table structure for table `pagecontent`
--

CREATE TABLE IF NOT EXISTS `pagecontent` (
  `id` int(11) NOT NULL auto_increment,
  `content` text,
  `menu_link_id` int(11) NOT NULL,
  `htag` varchar(200) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `pagecontent`
--

INSERT INTO `pagecontent` (`id`, `content`, `menu_link_id`, `htag`) VALUES
(3, '<p><strong>WELCOME !</strong></p>\r\n<p>&nbsp;</p>\r\n<p>ASTHAM CENTER&nbsp;</p>', 2, '<p>&nbsp;ABOUT US</p>'),
(6, '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.co.in/maps?ll=26.957645,75.778064&amp;spn=0.002711,0.005284&amp;t=h&amp;z=18&amp;lci=com.panoramio.all"></iframe><br /><small><a href="http://maps.google.co.in/maps?ll=26.957645,75.778064&amp;spn=0.002711,0.005284&amp;t=h&amp;z=18&amp;lci=com.panoramio.all&amp;source=embed" style="color:#0000FF;text-align:left">View Larger Map</a></small>', 11, '<p><span style="font-size: large; "><strong>&nbsp;Location:&nbsp;</strong></span></p>');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `review_id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `date` datetime NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY  (`review_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`review_id`, `title`, `description`, `date`, `email`) VALUES
(13, 'Shree', 'whaa whaa', '0000-00-00 00:00:00', 'chitrdeshstar1@gmail.com'),
(11, 'Shree', 'whaa whaa', '0000-00-00 00:00:00', 'chitreshstar1@gmail.com'),
(12, 'oyelaa', 'kolya', '2012-03-14 19:00:57', ''),
(10, 'asdf', 'dddddd', '0000-00-00 00:00:00', 'adddd'),
(14, 'sdf', 'sdfadsf', '0000-00-00 00:00:00', 'sdf'),
(15, 'sdf', 'sdfa', '0000-00-00 00:00:00', 'ewr'),
(16, 'om', 'sldjfk', '0000-00-00 00:00:00', 'nmhh'),
(17, 'stomach pain', 'tell me medicin', '0000-00-00 00:00:00', 'chitreshstar11@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `reviews_comment`
--

CREATE TABLE IF NOT EXISTS `reviews_comment` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `date` datetime NOT NULL,
  `review_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `reviews_comment`
--

INSERT INTO `reviews_comment` (`id`, `name`, `email`, `description`, `date`, `review_id`, `status`) VALUES
(1, 'Shrikant Singhal', 'singhalshrikant@gmail.com', 'This is Fantastic. This is Very Good. I Like This. Thank You.', '2010-03-24 15:26:12', 1, 1),
(2, 'Shrikant Singhal', 'singhalshrikant@gmail.com', 'dfdfd', '2010-03-24 15:26:15', 1, 2),
(3, 'Onkar Singh', 'onkarsingh07@gmail.com', 'This is Cool.', '2010-03-24 15:53:51', 1, 1),
(4, 'happy', 'shrikantsinghalster@gmail.com', 'fdsfdsfs', '2010-03-24 16:10:28', 1, 1),
(5, 'Ramlal', 'sk.signhal@live.com', 'sfdsfsdfdssdf', '2010-03-24 16:16:29', 4, 2),
(6, 'Onkar Singh', 'onkarsingh07@gmail.com', 'This is Fine', '2010-03-24 16:37:46', 5, 1),
(7, 'Ramlal', 'singhalshrikant@gmail.com', 'hi', '2010-03-24 16:49:51', 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sproduct`
--

CREATE TABLE IF NOT EXISTS `sproduct` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `price` varchar(10) NOT NULL,
  `imgurl` varchar(255) NOT NULL,
  `category` int(11) NOT NULL,
  `description` text NOT NULL,
  `co_name` varchar(255) NOT NULL,
  `p_code` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `sproduct`
--

INSERT INTO `sproduct` (`id`, `name`, `price`, `imgurl`, `category`, `description`, `co_name`, `p_code`, `type`) VALUES
(1, 'Jaipur Cassette', '50000', 'Jaipur Cassette_download (3).jpg', 0, 'Microcool Cassette Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec libero. Suspendisse bibendum. Cras id urna. Morbi tincidunt, orci ac convallis aliquam, lectus turpis varius lorem, eu posuere nunc justo tempus leo. llorem, eu posuere nunc justo tempus leo. Donec mattis, purus nec placerat bibendum.', 'HITACHI', '29000', '');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE IF NOT EXISTS `subcategory` (
  `cat_name` varchar(255) NOT NULL,
  `subcat_name` varchar(255) NOT NULL,
  `subcat_id` int(255) NOT NULL auto_increment,
  `subcat_url` varchar(255) NOT NULL,
  `menu_link_id` int(11) NOT NULL default '1',
  PRIMARY KEY  (`subcat_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=104 ;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`cat_name`, `subcat_name`, `subcat_id`, `subcat_url`, `menu_link_id`) VALUES
('Chitresh2', 'we', 96, 'we_download (1).jpg', 1),
('Chitresh2', 'uiui', 100, 'uiui_images.jpg', 4),
('HELLO', 'one news', 91, 'one news_images (1).jpg', 7),
('Chitresh2', 'jjj', 99, 'jjj_download (2).jpg', 8),
('HELLO', 'OMMMM', 101, 'OMMMM_download (3).jpg', 2),
('Chitresh45', 'rt', 102, 'rt_download (6).jpg', 2),
('Chitresh2', 'tytyre', 103, 'tytyre_download.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `supercategory`
--

CREATE TABLE IF NOT EXISTS `supercategory` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `supercategory`
--

INSERT INTO `supercategory` (`id`, `name`) VALUES
(1, 'First 1'),
(2, 'First 2'),
(4, 'First 3'),
(5, 'FIRST4');
